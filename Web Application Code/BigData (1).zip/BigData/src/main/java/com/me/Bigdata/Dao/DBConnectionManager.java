package com.me.Bigdata.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class DBConnectionManager {
	
	public static final String dbUrl = "jdbc:mysql://localhost:3306/bigdata";
	
	public static final String user = "root";
	public static final String pwd = "root";
	private Connection connection;

	public Connection dbConnectionManager(String dbURL, String user, String pwd)
			throws ClassNotFoundException, SQLException {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			this.connection = DriverManager.getConnection(dbURL, user, pwd);
		} catch (SQLException e) {
			System.out.println("Connection failed! Check output console");
			e.printStackTrace();
		}
		if (connection != null) {
			// System.out.println("You have connected with the database, import
			// or export files now");
		} else {
			System.out.println("Failed to make the database connection");
		}
		return connection;
	}

	public Connection getConnection() {
		return this.connection;
	}

}
