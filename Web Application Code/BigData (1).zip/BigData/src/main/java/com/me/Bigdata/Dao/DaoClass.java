package com.me.Bigdata.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.me.Bigdata.pojo.Movie;;

public class DaoClass {

	Statement stmt = null;
	Connection conn = null;
	PreparedStatement pstmt = null;

	public List<Movie> fetchcomedyMovies() throws SQLException, ClassNotFoundException {

		List<Movie> movieList = new ArrayList<Movie>();
		String query = "SELECT * FROM top10comedies";
		DBConnectionManager dbm = new DBConnectionManager();

		try {
			conn = dbm.dbConnectionManager(DBConnectionManager.dbUrl, DBConnectionManager.user,
					DBConnectionManager.pwd);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next()) {
				Movie movie = new Movie();
				movie.setImdbID(rs.getString(1));
				movie.setDirector(rs.getString(2));
				movie.setTittle(rs.getString(3));
				movie.setActors(rs.getString(4));
				movie.setImdbRating(rs.getFloat(5));
				movie.setImdbVote(rs.getInt(6));
				movie.setRuntime(rs.getInt(7));
				movie.setAwards(rs.getString(8));
				movie.setYear(rs.getInt(9));
				movie.setLanguage(rs.getString(10));
				movie.setCountry(rs.getString(11));
				movie.setWriter(rs.getString(12));
				movie.setPoster(rs.getString(13));
				movie.setOscarWinner(rs.getInt(14));
				movie.setOscarNominated(rs.getInt(15));
				movie.setOtherAwards(rs.getInt(16));
				movieList.add(movie);

			}
			
					
		
	    stmt.close();
		
		return movieList;

	}
	
	public List<Movie> fetchtopMovies() throws SQLException, ClassNotFoundException {

		List<Movie> movieList = new ArrayList<Movie>();
		String query = "SELECT * FROM bigdata.movies1  where AmazonID IN ('6302985064','6300247171','B00004CQNI','780020715','6300213773','B000AU9UYW')";

		DBConnectionManager dbm = new DBConnectionManager();

		try {
			conn = dbm.dbConnectionManager(DBConnectionManager.dbUrl, DBConnectionManager.user,
					DBConnectionManager.pwd);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next()) {
				Movie movie = new Movie();
				movie.setImdbID(rs.getString(1));
				movie.setDirector(rs.getString(2));
				movie.setTittle(rs.getString(3));
				movie.setActors(rs.getString(4));
				movie.setImdbRating(rs.getFloat(5));
				movie.setImdbVote(rs.getInt(6));
				movie.setRuntime(rs.getInt(8));
				movie.setAwards(rs.getString(9));
				movie.setYear(rs.getInt(10));
			    movie.setGenre(rs.getString(15));
				movie.setPoster(rs.getString(17));
				movie.setAmazonID(rs.getString(14));
				movieList.add(movie);

			}
			
					
		
	    stmt.close();
		
		return movieList;

	}
	
	public List<Movie> fetchhorrorMovies() throws SQLException, ClassNotFoundException {

		List<Movie> movieList = new ArrayList<Movie>();
		String query = "SELECT * FROM top10horrors";
		DBConnectionManager dbm = new DBConnectionManager();

		try {
			conn = dbm.dbConnectionManager(DBConnectionManager.dbUrl, DBConnectionManager.user,
					DBConnectionManager.pwd);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next()) {
				Movie movie = new Movie();
				movie.setImdbID(rs.getString(1));
				movie.setDirector(rs.getString(2));
				movie.setTittle(rs.getString(3));
				movie.setActors(rs.getString(4));
				movie.setImdbRating(rs.getFloat(5));
				movie.setImdbVote(rs.getInt(6));
				movie.setRuntime(rs.getInt(7));
				movie.setAwards(rs.getString(8));
				movie.setYear(rs.getInt(9));
				movie.setLanguage(rs.getString(10));
				movie.setCountry(rs.getString(11));
				movie.setWriter(rs.getString(12));
				movie.setPoster(rs.getString(13));
				movie.setOscarWinner(rs.getInt(14));
				movie.setOscarNominated(rs.getInt(15));
				movie.setOtherAwards(rs.getInt(16));
				movieList.add(movie);

			}
			
					
		
	    stmt.close();
		
		return movieList;

	}
	
	
	public List<Movie> fetchromanticMovies() throws SQLException, ClassNotFoundException {

		List<Movie> movieList = new ArrayList<Movie>();
		String query = "SELECT * FROM top10romantic";
		DBConnectionManager dbm = new DBConnectionManager();

		try {
			conn = dbm.dbConnectionManager(DBConnectionManager.dbUrl, DBConnectionManager.user,
					DBConnectionManager.pwd);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next()) {
				Movie movie = new Movie();
				movie.setImdbID(rs.getString(1));
				movie.setDirector(rs.getString(2));
				movie.setTittle(rs.getString(3));
				movie.setActors(rs.getString(4));
				movie.setImdbRating(rs.getFloat(5));
				movie.setImdbVote(rs.getInt(6));
				movie.setRuntime(rs.getInt(7));
				movie.setAwards(rs.getString(8));
				movie.setYear(rs.getInt(9));
				movie.setLanguage(rs.getString(10));
				movie.setCountry(rs.getString(11));
				movie.setWriter(rs.getString(12));
				movie.setPoster(rs.getString(13));
				movie.setOscarWinner(rs.getInt(14));
				movie.setOscarNominated(rs.getInt(15));
				movie.setOtherAwards(rs.getInt(16));
				movieList.add(movie);

			}
			
					
		
	    stmt.close();
		
		return movieList;

	}
	
	public List<Movie> fetchmysteryMovies() throws SQLException, ClassNotFoundException {

		List<Movie> movieList = new ArrayList<Movie>();
		String query = "SELECT * FROM top10mysthrill";
		DBConnectionManager dbm = new DBConnectionManager();

		try {
			conn = dbm.dbConnectionManager(DBConnectionManager.dbUrl, DBConnectionManager.user,
					DBConnectionManager.pwd);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next()) {
				Movie movie = new Movie();
				movie.setImdbID(rs.getString(1));
				movie.setDirector(rs.getString(2));
				movie.setTittle(rs.getString(3));
				movie.setActors(rs.getString(4));
				movie.setImdbRating(rs.getFloat(5));
				movie.setImdbVote(rs.getInt(6));
				movie.setRuntime(rs.getInt(7));
				movie.setAwards(rs.getString(8));
				movie.setYear(rs.getInt(9));
				movie.setLanguage(rs.getString(10));
				movie.setCountry(rs.getString(11));
				movie.setWriter(rs.getString(12));
				movie.setPoster(rs.getString(13));
				movie.setOscarWinner(rs.getInt(14));
				movie.setOscarNominated(rs.getInt(15));
				movie.setOtherAwards(rs.getInt(16));
				movieList.add(movie);

			}
			
					
		
	    stmt.close();
		
		return movieList;

	}
	
	public List<Movie> fetchsciMovies() throws SQLException, ClassNotFoundException {

		List<Movie> movieList = new ArrayList<Movie>();
		String query = "SELECT * FROM top10scifi";
		DBConnectionManager dbm = new DBConnectionManager();

		try {
			conn = dbm.dbConnectionManager(DBConnectionManager.dbUrl, DBConnectionManager.user,
					DBConnectionManager.pwd);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next()) {
				Movie movie = new Movie();
				movie.setImdbID(rs.getString(1));
				movie.setDirector(rs.getString(2));
				movie.setTittle(rs.getString(3));
				movie.setActors(rs.getString(4));
				movie.setImdbRating(rs.getFloat(5));
				movie.setImdbVote(rs.getInt(6));
				movie.setRuntime(rs.getInt(7));
				movie.setAwards(rs.getString(8));
				movie.setYear(rs.getInt(9));
				movie.setLanguage(rs.getString(10));
				movie.setCountry(rs.getString(11));
				movie.setWriter(rs.getString(12));
				movie.setPoster(rs.getString(13));
				movie.setOscarWinner(rs.getInt(14));
				movie.setOscarNominated(rs.getInt(15));
				movie.setOtherAwards(rs.getInt(16));
				movieList.add(movie);

			}
			
					
		
	    stmt.close();
		
		return movieList;

	}
	
	public List<String> similarMovies(String id) throws SQLException, ClassNotFoundException {

	
		String query = "SELECT * FROM movie_similar where imdb_id='"+id+"'";
		DBConnectionManager dbm = new DBConnectionManager();

		try {
			conn = dbm.dbConnectionManager(DBConnectionManager.dbUrl, DBConnectionManager.user,
					DBConnectionManager.pwd);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			List<String> results = new ArrayList<String>();
			
			
			while (rs.next()) {              
		        int i = 3;
		        while(i <= 12) {
		        	results.add(rs.getString(i++));
		        }
		       
		}
			
			stmt.close();
			
					
		
	    
		
		return results;

	}
	
	
public Movie similarMovies2(String id) throws SQLException, ClassNotFoundException {

		
		Movie movie = new Movie();
		String query = "SELECT * FROM movies1 where AmazonID='"+id+"'";
		DBConnectionManager dbm = new DBConnectionManager();

		try {
			conn = dbm.dbConnectionManager(DBConnectionManager.dbUrl, DBConnectionManager.user,
					DBConnectionManager.pwd);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		
		stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery(query);
		while (rs.next()) {
			
			movie.setImdbID(rs.getString(1));
			movie.setDirector(rs.getString(2));
			movie.setTittle(rs.getString(3));
			movie.setActors(rs.getString(4));
			movie.setImdbRating(rs.getFloat(5));
			movie.setImdbVote(rs.getInt(6));
			movie.setRuntime(rs.getInt(8));
			movie.setAwards(rs.getString(9));
			movie.setYear(rs.getInt(10));
			movie.setLanguage(rs.getString(11));
			movie.setCountry(rs.getString(12));
			movie.setGenre(rs.getString(15));
			movie.setWriter(rs.getString(16));
			movie.setPoster(rs.getString(17));
			movie.setOscarWinner(rs.getInt(18));
			movie.setOscarNominated(rs.getInt(19));
			movie.setOtherAwards(rs.getInt(20));
			

		}
		
				
	
    stmt.close();
	
	return movie;

	}

  public String user(String name) throws SQLException, ClassNotFoundException {
	   
	    String value = null;
		String query = "SELECT * FROM users where username='"+name+"'";
		DBConnectionManager dbm = new DBConnectionManager();

		try {
			conn = dbm.dbConnectionManager(DBConnectionManager.dbUrl, DBConnectionManager.user,
					DBConnectionManager.pwd);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		
		stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery(query);
		while (rs.next()){
            value = rs.getString(2);
    } 
  
    stmt.close();
	
	return value;

	
}
  
  
  public List<String> userMovies(String id) throws SQLException, ClassNotFoundException {

		
		String query = "SELECT * FROM user_recommend where user_id='"+id+"'";
		DBConnectionManager dbm = new DBConnectionManager();

		try {
			conn = dbm.dbConnectionManager(DBConnectionManager.dbUrl, DBConnectionManager.user,
					DBConnectionManager.pwd);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			List<String> results = new ArrayList<String>();
			
			
			while (rs.next()) {              
		        int i = 3;
		        while(i <= 12) {
		        	results.add(rs.getString(i++));
		        }
		       
		}
			
			stmt.close();
			
		
		return results;

	}
  
  
  
  public Movie userRecommend(String id) throws SQLException, ClassNotFoundException {

		
		Movie movie = new Movie();
		String query = "SELECT * FROM movies1 where AmazonID='"+id+"'";
		DBConnectionManager dbm = new DBConnectionManager();

		try {
			conn = dbm.dbConnectionManager(DBConnectionManager.dbUrl, DBConnectionManager.user,
					DBConnectionManager.pwd);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		
		stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery(query);
		while (rs.next()) {
			
			movie.setImdbID(rs.getString(1));
			movie.setDirector(rs.getString(2));
			movie.setTittle(rs.getString(3));
			movie.setActors(rs.getString(4));
			movie.setImdbRating(rs.getFloat(5));
			movie.setImdbVote(rs.getInt(6));
			movie.setRuntime(rs.getInt(8));
			movie.setAwards(rs.getString(9));
			movie.setYear(rs.getInt(10));
			movie.setLanguage(rs.getString(11));
			movie.setCountry(rs.getString(12));
			movie.setGenre(rs.getString(15));
			movie.setWriter(rs.getString(16));
			movie.setPoster(rs.getString(17));
			movie.setOscarWinner(rs.getInt(18));
			movie.setOscarNominated(rs.getInt(19));
			movie.setOtherAwards(rs.getInt(20));
			

		}
		
				
	
  stmt.close();
	
	return movie;

	}



}