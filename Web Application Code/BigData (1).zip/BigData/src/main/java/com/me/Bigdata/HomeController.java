package com.me.Bigdata;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate;

import com.me.Bigdata.Dao.DaoClass;
import com.me.Bigdata.pojo.Movie;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	
	@Autowired
	@Qualifier("DaoClass")
	DaoClass daoClass;
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );
		
		return "home";
	}
	
	@RequestMapping(value = "home.htm", method = RequestMethod.GET)
	public String home2(Locale locale, Model model) {
	
		
		return "home";
	}
	
	@RequestMapping(value = "dataanalysis.htm", method = RequestMethod.GET)
	public String dataanalysis(Locale locale, Model model) throws ClassNotFoundException, SQLException {
	
		List<Movie> movieList = new ArrayList<Movie>();
		movieList = daoClass.fetchtopMovies();
		
		model.addAttribute("movieList", movieList);
		
		return "dataanalysis";
	}
	
	@RequestMapping(value = "recommend.htm", method = RequestMethod.GET)
	public String recommendation(HttpServletRequest request, Locale locale, Model model) throws ClassNotFoundException, SQLException {
	
		HttpSession session = request.getSession();
		String user1= (String) session.getAttribute("username1");
			
		List<Movie> movieList = new ArrayList<Movie>();
		List<String> results = new ArrayList<String>();
		results = daoClass.userMovies(user1);
		for (int i=0; i<results.size();i++){
			
			movieList.add(daoClass.userRecommend(results.get(i)));
			System.out.println("i value"+results.get(i));
			
		}
		
		
		model.addAttribute("movieList", movieList);
		
		return "recommend";
	}
	
	@RequestMapping(value = "comedy.htm", method = RequestMethod.GET)
	public String topcomedy(Locale locale, Model model) throws ClassNotFoundException, SQLException {
	
		List<Movie> movieList = new ArrayList<Movie>();
		movieList = daoClass.fetchcomedyMovies();
		
		model.addAttribute("movieList", movieList);
		return "comedy";
	}
	
	
	@RequestMapping(value = "horror.htm", method = RequestMethod.GET)
	public String tophorror(Locale locale, Model model) throws ClassNotFoundException, SQLException {
	
		List<Movie> movieList = new ArrayList<Movie>();
		movieList = daoClass.fetchhorrorMovies();
		
		model.addAttribute("movieList", movieList);
		return "horror";
	}
	
	@RequestMapping(value = "romance.htm", method = RequestMethod.GET)
	public String topromance(Locale locale, Model model) throws ClassNotFoundException, SQLException {
	
		List<Movie> movieList = new ArrayList<Movie>();
		movieList = daoClass.fetchromanticMovies();
		
		model.addAttribute("movieList", movieList);
		return "romantic";
	}
	
	@RequestMapping(value = "mystery.htm", method = RequestMethod.GET)
	public String topmystery(Locale locale, Model model) throws ClassNotFoundException, SQLException {
	
		List<Movie> movieList = new ArrayList<Movie>();
		movieList = daoClass.fetchmysteryMovies();
		
		model.addAttribute("movieList", movieList);
		return "thriller";
	}	
	
	
	
	
	@RequestMapping(value = "sci.htm", method = RequestMethod.GET)
	public String topsci(Locale locale, Model model) throws ClassNotFoundException, SQLException {
	
		List<Movie> movieList = new ArrayList<Movie>();
		movieList = daoClass.fetchsciMovies();
		
		model.addAttribute("movieList", movieList);
		return "scifi";
	}	
	
	@RequestMapping(value = "similarmovie.htm", method = RequestMethod.GET)
	public String similarMovie(HttpServletRequest request,HttpServletResponse response, Locale locale, Model model) throws ClassNotFoundException, SQLException {
	
		String id = request.getParameter("id");
		List<Movie> movieList = new ArrayList<Movie>();
		List<String> results = new ArrayList<String>();
		results = daoClass.similarMovies(id);
		for (int i=0; i<results.size();i++){
			
			movieList.add(daoClass.similarMovies2(results.get(i)));
			System.out.println("i value"+results.get(i));
			
		}
		
		
		model.addAttribute("movieList", movieList);
		return "similar";
	}	
	
	
	@RequestMapping(value = "sign.htm", method = RequestMethod.POST)
	public String signup(HttpServletRequest request,HttpServletResponse response, Locale locale, Model model) throws ClassNotFoundException, SQLException {
	
		String user = request.getParameter("user");
		String username1 = daoClass.user(user);
		System.out.println("user"+username1);
		HttpSession session = request.getSession();
		session.setAttribute("username1", username1);
		return "home";
	}	
	
	@RequestMapping(value = "/logout.htm", method = RequestMethod.GET)
	public String logout(Model model, HttpServletRequest req) {
		req.getSession().invalidate();
		return "home";

	}
	
	
	
	@RequestMapping(value = "tableau.htm", method = RequestMethod.GET)
	public String tableau(Locale locale, Model model) throws ClassNotFoundException, SQLException {
		
		return "tableau";
		
	}
	
	@RequestMapping(value = "machine.htm", method = RequestMethod.GET)
	public String movieRatingCall(Locale locale, Model model) throws ClassNotFoundException, SQLException {
		
		return "machineRating";
		
	}
	
	
	@RequestMapping(value="/movieRatingPredict", method= RequestMethod.POST)
	public String submitPredictMovieRating(HttpServletRequest request,HttpServletResponse response) throws IOException {

		PrintWriter out = response.getWriter();
		
		String director = request.getParameter("director").replaceAll("'", "");
		String writer = request.getParameter("writer").replaceAll("'", "");
		//String fnlwgt = request.getParameter("fnlwght");
		String actor = request.getParameter("actor").replaceAll("'", "");
		
	/*	String education_num = "13";*/
		String genre = request.getParameter("genre").replaceAll("'", "");
		String runtime = request.getParameter("runtime");
		String imdbvote = request.getParameter("imdbvote");
	/*	String race = request.getParameter("race");
		String sex = request.getParameter("sex");*/
		String country = request.getParameter("country").replaceAll("'", "");
		String oscarWinner = request.getParameter("oscarWinner");
		String oscarNominated = request.getParameter("oscarNominated");
		String otherAwards = request.getParameter("otherAwards");
		String year = request.getParameter("year");
		//you may want to visit this website to see the structure of the data being returned by this URL
		String urlOfTheRestService = "https://ussouthcentral.services.azureml.net/workspaces/ef99575e728e482f8fbe54bc4d452a1d/services/61002ea68e9c45578f9669d643deaea6/execute?api-version=2.0&format=swagger";
		HttpHeaders headers = new HttpHeaders();
		headers.add("Authorization", "Bearer iw5+Ss8jJV9rqdtv2Of4Wr6Fc/PCIbj4HDYC04IKd8yTT6k/DvkIf1PXCuzB8OzxQRbp6oqhh3krT7cO0ustcw==");
		headers.add("Content-Length", "100000");
		headers.add("Content-Type", "application/json");
		
		//MultiValueMap<String, Integer> body = new LinkedMultiValueMap<String, Integer>();
		
	//	String requestJson = "{'Inputs': {'input1': {'ColumnNames': ['Released','imdbID','Director','Title','Actor','imdbRating','imdbVote','AmazonAvgScore','runtime','Awards','Year','Language',''Country','AmazonTitle','AmazonID','Genre','Writer','Poster','OscarWinner','OscarNominated','otherAwards'],'Values': [['null','null','"+director+"','null','"+actor+"','"+'0'+"','"+imdbvote+'0'+"','"+runtime+"','null','"+year+"','"+"English"+"','"+country+"','"+"null"+"','"+"null"+"','"+genre+"','"+writer+"','null','"+oscarWinner+"','"+oscarNominated+"','"+otherAwards+"']]}},'GlobalParameters': {} }";
		//String requestJson = "{'Inputs': {'input1': ['Released','imdbID','Director','Title','Actor','imdbRating','imdbVote','AmazonAvgScore','runtime',	'Awards','Year','Language','Country','AmazonTitle','AmazonID','Genre','Writer','Poster','OscarWinner','OscarNominated','OtherAwards'],'Values': ['1-Feb-04','xyz','"+director+"','title','"+actor+"','0','"+imdbvote+"','0','"+runtime+"','no wins','"+year+"','English','"+country+"','title','null','"+genre+"','"+writer+"','abc','"+oscarWinner+"','"+oscarNominated+"','"+otherAwards+"']},'GlobalParameters': {}}";
		//String requestJson = "{'Inputs': {'input1': {'ColumnNames': ['age','workclass','education','marital-status','occupation','relationship','capital-gain','capital-loss','hours-per-week','result']																									 ,'Values': [['"+age+"','"+workClass+"','"+education+"','"+marital_status+"','"+occupation+"','"+relationship+"','"+capital_gain+"','"+capital_loss+"','"+hours_per_week+"','<=50K']]}},'GlobalParameters': {} }";

		String requestJson="{'Inputs': {'input1': [{'Released': '31-Jul-09','imdbID': 'tt1286871','Director': '"+director+"','Title': 'title','Actor': '"+actor+"','imdbRating': "+0+",'imdbVote': '"+imdbvote+"','AmazonAvgScore': "+0+",'runtime': '"+runtime+"','Awards': '2 wins.','Year': "+year+",'Language': 'Hindi\t English','Country': '"+country+"','AmazonTitle': 'Yes\t Madam!','AmazonID': 'B000009HII','Genre': '"+genre+"','Writer': '"+writer+"','Poster': 'poster','OscarWinner':"+oscarWinner+",'OscarNominated': "+oscarNominated+",'OtherAwards': "+otherAwards+"}]},'GlobalParameters': {}}";		
				
		HttpEntity<String> entity = new HttpEntity<String>(requestJson,headers);

		System.out.println("entity..............."+entity);
		//It simplifies communication with HTTP servers, and enforces RESTful principles
		RestTemplate restTemplate = new RestTemplate();

		String restData = restTemplate.postForObject(urlOfTheRestService, entity, String.class);
		
		System.out.println("Data" + restData);
		
		JSONObject obj = null;
		try {
			obj = new JSONObject(restData);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		out.print(obj);
		
		return null;
	}
}
