package com.me.Bigdata.pojo;

public class Movie {
	
	private String imdbID;
	
	private String amazonID;
	
	
	private String director;
	
	private String tittle;
	
	private String actors;
	
	private String genre;
	
	private float imdbRating;
	
	private int imdbVote;
	
	private int runtime;
	
	private String awards;
	
	private int year;
	
	private String language;
	
	private String country;
	
	private String writer;
	
	private String poster;
	
	private int oscarWinner;
	
	private int oscarNominated;
	
	private int otherAwards;

	public String getImdbID() {
		return imdbID;
	}

	public void setImdbID(String imdbID) {
		this.imdbID = imdbID;
	}
	
	public String getAmazonID() {
		return amazonID;
	}

	public void setAmazonID(String amazonID) {
		this.amazonID = amazonID;
	}


	public String getDirector() {
		return director;
	}

	public void setDirector(String director) {
		this.director = director;
	}

	public String getTittle() {
		return tittle;
	}

	public void setTittle(String tittle) {
		this.tittle = tittle;
	}

	public String getActors() {
		return actors;
	}

	public void setActors(String actors) {
		this.actors = actors;
	}

	public float getImdbRating() {
		return imdbRating;
	}

	public void setImdbRating(float imdbRating) {
		this.imdbRating = imdbRating;
	}

	public int getImdbVote() {
		return imdbVote;
	}

	public void setImdbVote(int imdbVote) {
		this.imdbVote = imdbVote;
	}

	public int getRuntime() {
		return runtime;
	}

	public void setRuntime(int runtime) {
		this.runtime = runtime;
	}

	public String getAwards() {
		return awards;
	}

	public void setAwards(String awards) {
		this.awards = awards;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getWriter() {
		return writer;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}

	public String getPoster() {
		return poster;
	}

	public void setPoster(String poster) {
		this.poster = poster;
	}

	public int getOscarWinner() {
		return oscarWinner;
	}

	public void setOscarWinner(int oscarWinner) {
		this.oscarWinner = oscarWinner;
	}

	public int getOscarNominated() {
		return oscarNominated;
	}

	public void setOscarNominated(int oscarNominated) {
		this.oscarNominated = oscarNominated;
	}

	public int getOtherAwards() {
		return otherAwards;
	}

	public void setOtherAwards(int otherAwards) {
		this.otherAwards = otherAwards;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}
	
	
	
	

}
