$( document ).ready(function() {
    console.log( "ready!" );
    
    $("#submitBtn").click(function(){
    	
    	$.post("movieRatingPredict",$("#analyseForm").serialize(), function( data ) {
    		
    		 var json = JSON.parse(data);
				var data1=json.Results.output1[0];			
				$("#result").val(data1["Scored Labels"].substring(0,5));
				$("#result").css({'background-color' : '#b2ffb2'});
			});
    });
});